package Servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import Bean.Catgery;
import Bean.Catlaog;
import Bean.product;
import Bean.subcart;
import Dao.ProductDao;

@WebServlet("/Product2")
public class Product2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
	}
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String cname=request.getParameter("COUNTNAME");
		String rupe	=request.getParameter("RUPEE");
	//	PrintWriter out=response.getWriter();
		Catlaog cat=new Catlaog(cname, rupe); 
		cat.setCOUNTNAME(cname);
		cat.setRUPEE(rupe);
	int	j=ProductDao.Cat(cat);
		if(j>0)
		{
			String cate=request.getParameter("CATE_N");
			String subcate=request.getParameter("SUB_CATE");
			Catgery ctg=new Catgery(cate,subcate,cname);
			ctg.setCATE_N(cate);
			ctg.setSUB_CATE(subcate);
		int i=	ProductDao.catg(ctg);
			if(i>0)
			{
				subcart sb=new subcart(subcate);
				sb.setSUB_CATE(subcate);
				int k=ProductDao.subc(sb);
				if(k>0)
				{
					Part photo=null;
					InputStream in = null;
					try
					{
						photo=request.getPart("pdt_image");
						
						in=photo.getInputStream();
					}
					catch(Exception e){
						System.out.print(e.getMessage());
					}
					String pdtname=request.getParameter("pdt_name");
					String pdtdesc=request.getParameter("pdt_desc");
					String pdtqua=request.getParameter("pdt_qua");
					String pdtprice=request.getParameter("pdt_price");
					ProductDao pd=new ProductDao() ;
					product pd1=new product(cname, pdtname, subcate, pdtdesc,pdtqua, pdtprice);
					pd1.setPDT_NAME(pdtname);
					pd1.setPDT_DESC(pdtdesc);
					pd1.setPDT_QUA(pdtqua);
					pd1.setPDT_PRICE(pdtprice);
					int p=ProductDao.pdt(pd1, photo);
					PrintWriter out=response.getWriter();
					if(p>0)
					{
						out.print("<script>");
						out.print("alert('Product Added');");
						out.print("location=admin.jsp");
						out.print("</script>");
						
					}
					out.print("<script>");
					out.print("alert('Product Add Failed');");
					out.print("location=admin.jsp");
					out.print("</script>");
				
						
				}
			}
			
		}
		else
		{
			System.out.print("Cat is not included");
		}
		
	}

}
