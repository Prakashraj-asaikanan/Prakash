package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.codbean;
import Bean.getcod;
import Dao.codDao;
@WebServlet("/Cod")
public class Cod extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Cod() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.print(76);
		int qt=Integer.parseInt(request.getParameter("qt"));
		String id=request.getParameter("id");
		String username=request.getParameter("field1");
		long phno=Long.parseLong(request.getParameter("phno"));
		int pino=Integer.parseInt(request.getParameter("pin"));
		String local=request.getParameter("local");
		String state=request.getParameter("state");
		String add=(String)request.getParameter("add");
	//	String username=(String)ses.getAttribute("field1");
		codbean c=new codbean();
		c.setId(id);
		c.setUsername(username);
		//codDao.getcar(username);
		
		PrintWriter out=response.getWriter();
		Random rand = new Random(); 
		 String pickedNumber = (String.valueOf(rand.nextInt(2000) + 1)); 
		getcod g=new getcod();
		g.setPdtid(id);
		g.setUsername(username);
		g.setOrderid(pickedNumber);
		g.setQunat(qt);
		g.setPinno(pino);
		g.setAdd(add);
		g.setPhno(phno);
		g.setLocal(local);
		g.setState(state);
		int j=codDao.getcar(g);
		if(j>0)
		{
			response.sendRedirect("Sucess.jsp");
		}
		else
		{
			response.sendRedirect("Failure.jsp");
		}
		
		
	}

}
