package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Bean.*;
import Servlet.DBConnection;

public class codDao {

	
	public static int getcar(getcod un) 
	{
		int t=0;
		try
		{
			String tr="";
			Connection con=DBConnection.getConnection();
			System.out.print(45);
			String str="SELECT EMAIL FROM REG12 WHERE USERNAME=?";
			String str1="INSERT INTO USERORDER values(?,?,?,?,?,?,?,?,?,?)";
		   PreparedStatement ps=con.prepareStatement(str);
		   ps.setString(1, un.getUsername());
		    ResultSet rs=ps.executeQuery();
		   if(rs.next())
		  {
			   tr=rs.getString(1);
		  }
			  // un=new getcod();	
			//   System.out.print(7);
			   PreparedStatement ps1=con.prepareStatement(str1);
			   ps1.setString(1,un.getUsername());
			   ps1.setString(2,un.getOrderid());
			   ps1.setString(3,un.getPdtid());
			   ps1.setInt(4, un.getQunat());
			   ps1.setInt(5,un.getPinno());
			   ps1.setString(6,un.getAdd());
			   ps1.setLong(7, un.getPhno());
			   ps1.setString(8,un.getLocal());
			   ps1.setString(9, un.getState());
			   ps1.setString(10,tr);
			   t=ps1.executeUpdate();
			   
	//	   }
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.print(t);
		return t;
			}
		
	}
