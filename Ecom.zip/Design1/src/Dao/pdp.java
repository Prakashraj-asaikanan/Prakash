package Dao;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Base64;

import Bean.Pdpbean;
import Servlet.DBConnection;

public class pdp {
	

	public static Pdpbean pdr(Pdpbean f)
	{
		ResultSet rs=null;
		Blob blo=null;
		String qun="";
		Pdpbean pd=null;
		String imgDataBase64="";
		try
		{
			//String id=request.getParameter("id");
			Connection con=DBConnection.getConnection();
			String Query="SELECT * FROM PRODUCT where PDT_ID=?";
			PreparedStatement ps=con.prepareStatement(Query);
			ps.setString(1,f.getID());
			 rs=ps.executeQuery();
			while(rs.next()){
			 pd=new Pdpbean();
			pd.setName(rs.getString(2));
			pd.setQuan(rs.getString(6));
			pd.setPrice(rs.getString(7));
				blo=rs.getBlob(8);
				int size=(int)blo.length();
				byte[] bloa=blo.getBytes(1,size);
				imgDataBase64=new String(Base64.getEncoder().encode(bloa));
				pd.setImgDataBase64(imgDataBase64);
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return pd;
	}

}
