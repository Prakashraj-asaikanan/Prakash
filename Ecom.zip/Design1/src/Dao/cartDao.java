package Dao;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;

import Bean.Index;
import Bean.Pdpbean;
import Bean.cart;
import Bean.cart12;
import Bean.sample;
import Servlet.DBConnection;

public class cartDao {
	

	public static ArrayList<cart12> getcart(String un) 
	{
		cart12 c=null;
		ArrayList<cart12> list=new ArrayList<cart12>();
		try
		{
		Connection con=DBConnection.getConnection();
		String str="SELECT * FROM USERORDER WHERE USERNAME=?";
		String str1="SELECT * FROM PRODUCT WHERE PDT_ID=?";
		PreparedStatement ps=con.prepareStatement(str);
		ps.setString(1,un);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			c=new cart12();
			PreparedStatement ps2=con.prepareStatement(str1);
			ps2.setString(1, rs.getString(3));
			ResultSet rs2=ps2.executeQuery();
			String img="";
			int pri=0;
			while(rs2.next())
			{
				pri=Integer.parseInt(rs2.getString(7));
				Blob b=rs2.getBlob(8);
				int size=(int)b.length();
				byte[] bloa=b.getBytes(1,size);
				img=new String(java.util.Base64.getEncoder().encode(bloa));
				
				//System.out.print(96666+""+pri+""+9666);
			}
			c.setPdtimage(img);
			c.setID(rs.getString(2));
			c.setPrice(String.valueOf(pri));
			int tp=pri*rs.getInt(4);
			c.setQuantity(rs.getInt(4));
			c.setTotalprice(tp);
			list.add(c);
			c=null;
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
}