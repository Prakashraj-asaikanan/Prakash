package Dao;
import java.sql.*;
import java.util.ArrayList;
import Bean.Index;
import Servlet.DBConnection;

public class IndexDao {

	public static ArrayList<Index> getinde(String Srt)
	{
		ArrayList<Index> list=new ArrayList<Index>();
		try
		{
			String na="";
			String pri="";
			String id="";
			String img="";
			Blob blo=null;
						String imgDataBase64="";
		Connection con=DBConnection.getConnection();
		//java.sql.Statement st=con.createStatement();
		String sql="SELECT * FROM PRODUCT where PDT_ID  BETWEEN  160 AND 250	";
	PreparedStatement ps=con.prepareStatement(sql);
	//ps.setString(1, "Blazzers");
		ResultSet rs=ps.executeQuery();
		Index k=null;
		while(rs.next())
		{	k=new Index();
			k.setPDT_Name(rs.getString(2));
			k.setPDT_ID(rs.getString(3));
			k.setPDT_PRICE(rs.getString(7));
			blo=rs.getBlob(8);
			int size=(int)blo.length();
			byte[] bloa=blo.getBytes(1,size);
			imgDataBase64=new String(java.util.Base64.getEncoder().encode(bloa));
		k.setPDT_IMG(imgDataBase64);			
			list.add(k);
			k=null;
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
}
