package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import Bean.cate;
import Servlet.DBConnection;

public class catDao {
	
	public static ArrayList<cate> cat()
	{
		cate cv=new cate();
		ArrayList<cate> list=new ArrayList<cate>();
		try
		{
			Connection con=DBConnection.getConnection();
			PreparedStatement p=con.prepareStatement("SELECT SUB_CATE FROM CATEGORY WHERE id=1");
			ResultSet r=p.executeQuery();
			if(r.next())
			{
				cv.setCa(r.getString(1));
				list.add(cv);
			}	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list ;
	}

}
