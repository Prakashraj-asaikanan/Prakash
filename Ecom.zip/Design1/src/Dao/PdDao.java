package Dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.ResultSet;

import Bean.pdt;
import Servlet.DBConnection;

public class PdDao {
	
	public PdDao(pdt pdf) {
		// TODO Auto-generated constructor stub
		String h="1";
		try
		{
	
			Connection con=DBConnection.getConnection();
			String Query="SELECT * FROM PRODUCT where PDT_ID="+pdf.getId()+"";
			Statement st=(Statement) con.createStatement();
			ResultSet rs=((java.sql.Statement) st).executeQuery(Query);
			while(rs.next())
			{
				
			}
			
		}
		catch(Exception e)
		{
			
		}
	
	
	}
	
	

}
