package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import Bean.Index;
import Bean.SucessBean;
import Servlet.DBConnection;

public class SucessdAO {

	public static ArrayList<SucessBean> win(String uname)
	{
		ArrayList<SucessBean> list=new ArrayList<SucessBean>();
			try
			{
				
				SucessBean sb=null;
				Connection con=DBConnection.getConnection();
				String sd="select * from userorder where username=?";
				PreparedStatement ps=con.prepareStatement(sd);
				ps.setString(1,uname);
				ResultSet rs=ps.executeQuery();
				while(rs.next())
				{
					sb=new SucessBean();
					sb.setOrder_id(rs.getString(2));
					sb.setPdt_id(rs.getString(3));
					sb.setQunat(rs.getInt(4));
					sb.setPincode(rs.getInt(5));
					sb.setAddress(rs.getString(6));
					sb.setPhnum(rs.getLong(7));
					sb.setLocal(rs.getString(8));
					sb.setState(rs.getString(9));
					sb.setEmail(rs.getString(10));
					list.add(sb);
					sb=null;
					
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		
		return list;
	}
	
}
