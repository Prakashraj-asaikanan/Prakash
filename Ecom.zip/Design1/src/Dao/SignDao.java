package Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Bean.loginb;
public class SignDao {

			public static Connection getConnection() throws SQLException
			{
				Connection c = null;
			try {
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				c= DriverManager.getConnection("jdbc:oracle:thin:@106.51.0.187:1521:oracle","PRAKASH","prakash");
			}
			catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
			return c;
			}
			public static ResultSet save(loginb lg)
			{
				ResultSet status=null;
				try
				{
					Connection c=SignDao.getConnection();
					PreparedStatement	ps=c.prepareStatement("insert into reg12 values(?,?,?,?)");
					ps.setString(1,lg.getUsername());
					ps.setString(2,lg.getEmail());
					ps.setString(3,lg.getPassword());
					ps.setString(4,"2");
					status=ps.executeQuery();
					c.close();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				return status;
				
			}

		}

