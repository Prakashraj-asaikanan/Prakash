package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpSession;

import Bean.DeleteBean;
import Servlet.DBConnection;

public class DeleteDao {
	
	public static int del(DeleteBean aw)
	{
		int rs=0;
		try
		{
			//System.out.print("HAi");
		Connection con=DBConnection.getConnection();
		//System.out.print("HAi1");
		PreparedStatement ps=con.prepareStatement("delete from cart where username=?");
		ps.setString(1,aw.getUsername());
		//System.out.print(aw.getUsername());
		 rs=ps.executeUpdate();
		 //System.out.print("HAi2");
		// System.out.print(aw.getUsername());
		 System.out.println(rs);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return rs;
	}



}
