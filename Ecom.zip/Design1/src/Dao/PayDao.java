package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import Bean.cart;
import Servlet.DBConnection;

public class PayDao {
	
	public static int ca(cart f)
	{
		int t=0;
		try
		{
			Connection co=DBConnection.getConnection();
			PreparedStatement psw=co.prepareStatement("insert into cart values(?,?,?,?)");
			psw.setString(1,f.getUsername() );
			psw.setString(2, f.getPdt_id());
			psw.setString(3, f.getPdt_name());
			psw.setInt(4,f.getQuant());
			t=psw.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return t;
	}

}
