package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.Part;

import Bean.Catgery;
import Bean.Catlaog;
import Bean.product;
import Bean.subcart;
import Servlet.DBConnection;
public class ProductDao 
{
	public static int Cat(Catlaog cat)
	{
		int j=0;
		
		try
		{
			Connection con=DBConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into catalog values(countr_id.nextval,?,?)");
			ps.setString(1,cat.getCOUNTNAME());
			ps.setString(2, cat.getRUPEE());
			j=ps.executeUpdate();
			
		}
		catch(Exception e)
		{
			j=0;
			e.printStackTrace();
		}
		return j;
	}

	public static int catg(Catgery ctg)
	{
		int i=0;
		try
		{
			Connection con1=DBConnection.getConnection();
			PreparedStatement psd=con1.prepareStatement("select countid from catalog where catalog.countname='"+ctg.getCOUNTNAME()+"'");
			String stry = "";
			ResultSet rs9=psd.executeQuery();
			while(rs9.next())
			{
				stry=rs9.getString("countid");
			}
		
		PreparedStatement ps1=con1.prepareStatement("insert into category values(?,?,?,?)");
		ps1.setString(1,ctg.getCATE_N());
		ps1.setString(2,ctg.getSUB_CATE());
		ps1.setString(3,stry);
		ps1.setInt(4,3);
		i=ps1.executeUpdate();
	
		}
		
		catch(Exception e)
		{i=0;
		e.printStackTrace();}
		return i;
	}
	
	public static int subc(subcart sb)
	{
		int k=0;
		
		try
		{
			Connection con3=DBConnection.getConnection();
		PreparedStatement ps2=con3.prepareStatement("insert into subcat values(?,sub_id.nextval)");
		ps2.setString(1,sb.getSUB_CATE());
		ps2.executeUpdate();
		}
		catch(Exception e)
		{
			k=0;
			e.printStackTrace();
		}
		return k;
	}
	 
	public static int pdt(product pd,Part photo)
	{
		int p=0;
		try
		{
		Connection c=DBConnection.getConnection();
		PreparedStatement ps3=c.prepareStatement("insert into product values(?,?,pd_id.nextval,?,?,?,?,?,?)");
		ps3.setString(1, pd.getCATE_N());
		ps3.setString(2, pd.getPDT_NAME());
		ps3.setString(3,pd.getSCAT_NAME());
		ps3.setString(4,pd.getPDT_DESC());
		ps3.setString(5,pd.getPDT_QUA());
		ps3.setString(6,pd.getPDT_PRICE());
		ps3.setString(7,"66");
		ps3.setString(8,"85");
		p=ps3.executeUpdate();
		
		}
		catch(Exception e)
		{p=0;
			e.printStackTrace();		}
		return p;
	}
	
}
