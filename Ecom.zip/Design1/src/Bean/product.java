package Bean;
public class product {

	private String CATE_N;
	private String PDT_NAME;
	private String 	SCAT_NAME;
	private String  PDT_DESC;
	private String  PDT_QUA;
	private String PDT_PRICE;
	public product(String CATE_N,String PDT_NAME,String SCAT_NAME,String PDT_DESC,String PDT_QUA,String PDT_PRICE)
	{
		this.CATE_N=CATE_N;
		this.PDT_NAME=PDT_NAME;
		this.SCAT_NAME=SCAT_NAME;
		this.PDT_DESC=PDT_DESC;
		this.PDT_QUA=PDT_QUA;
		this.PDT_PRICE=PDT_PRICE;
		
	}
	public String getCATE_N() {
		return CATE_N;
	}
	public void setCATE_N(String cATE_N) {
		CATE_N = cATE_N;
	}
	public String getPDT_NAME() {
		return PDT_NAME;
	}
	public void setPDT_NAME(String pDT_NAME) {
		PDT_NAME = pDT_NAME;
	}
	public String getSCAT_NAME() {
		return SCAT_NAME;
	}
	public void setSCAT_NAME(String sCAT_NAME) {
		SCAT_NAME = sCAT_NAME;
	}
	public String getPDT_DESC() {
		return PDT_DESC;
	}
	public void setPDT_DESC(String pDT_DESC) {
		PDT_DESC = pDT_DESC;
	}
	public String getPDT_QUA() {
		return PDT_QUA;
	}
	public void setPDT_QUA(String pDT_QUA) {
		PDT_QUA = pDT_QUA;
	}
	public String getPDT_PRICE() {
		return PDT_PRICE;
	}
	public void setPDT_PRICE(String pDT_PRICE) {
		PDT_PRICE = pDT_PRICE;
	}
	
	
	
	
}
