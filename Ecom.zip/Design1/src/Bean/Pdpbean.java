package Bean;

import java.sql.Blob;

public class Pdpbean {

	
	private String ID;
	private String name;
	private String quan;
	private String price;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	private String blo;
	private String imgDataBase64;

	public Pdpbean()
	{
		
	}
	public Pdpbean(String ID)
	{
		this.ID=ID;
	}
	
	public Pdpbean(String name,String quan,String price,String imgDataBase64)
	{
		this.name=name;
		this.quan=quan;
		this.price=price;
		this.imgDataBase64=imgDataBase64;
	}
	
	public String getQuan() {
		return quan;
	}
	public void setQuan(String quan) {
		this.quan = quan;
	}
	public String getImgDataBase64() {
		return imgDataBase64;
	}
	public void setImgDataBase64(String blob) {
		this.imgDataBase64 = blob;
	}

	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	
	
}
