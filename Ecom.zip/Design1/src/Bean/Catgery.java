package Bean;

import Dao.ProductDao;

public class Catgery {

	private String CATE_N;
	private String SUB_CATE;
private String COUNTNAME;
public Catgery(String CATE_N,String SUB_CATE,String COUNTNAME)
{
	this.CATE_N=CATE_N;
	this.SUB_CATE=SUB_CATE;
this.COUNTNAME=COUNTNAME;
}
	public String getCOUNTNAME() {
	return COUNTNAME;
}
public void setCOUNTNAME(String cOUNTNAME) {
	COUNTNAME = cOUNTNAME;
}
	private int ID;
	ProductDao b=new ProductDao();
	
	
	public String getCATE_N() {
		return CATE_N;
	}
	public void setCATE_N(String cATE_N) {
		CATE_N = cATE_N;
	}
	public String getSUB_CATE() {
		return SUB_CATE;
	}
	public void setSUB_CATE(String sUB_CATE) {
		SUB_CATE = sUB_CATE;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	
}
