package Bean;

public class cart {
	
	private String username;
	private String pdt_id;
	private String pdt_name;
	private int quant;
	
	public cart()
	{
		
	}
	public cart(String usrname,String pdt_id,String pdt_name,int quant)
	{
		this.username=usrname;
		this.pdt_id=pdt_id;
		this.pdt_name=pdt_name;
		this.quant=quant;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPdt_id() {
		return pdt_id;
	}
	public void setPdt_id(String pdt_id) {
		this.pdt_id = pdt_id;
	}
	public String getPdt_name() {
		return pdt_name;
	}
	public void setPdt_name(String pdt_name) {
		this.pdt_name = pdt_name;
	}
	public int getQuant() {
		return quant;
	}
	public void setQuant(int quant) {
		this.quant = quant;
	}
	
	

}
