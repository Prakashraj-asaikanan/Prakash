package Bean;

public class getcod {
	
	private String username;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	private String orderid;
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	private String pdtid;
	private int qunat;
	private int pinno;
	private String add;
	private Long phno;
	private String local;
	private String state;
	
	public getcod()
	{	}
	public  getcod(String username,String orderid,String  pdid,int quan,int pinno,String add,Long phno,String local,String state)
	{
		this.username=username;
		this.orderid=orderid;
		this.pdtid=pdid;
		this.qunat=qunat;
		this.pinno=pinno;
		this.add=add;
		this.phno=phno;
		this.local=local;
		this.state=state;
		
	}
	public String getPdtid() {
		return pdtid;
	}
	public void setPdtid(String pdtid) {
		this.pdtid = pdtid;
	}
	public int getQunat() {
		return qunat;
	}
	public void setQunat(int qunat) {
		this.qunat = qunat;
	}
	public int getPinno() {
		return pinno;
	}
	public void setPinno(int pinno) {
		this.pinno = pinno;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	public Long getPhno() {
		return phno;
	}
	public void setPhno(Long phno) {
		this.phno = phno;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
}
