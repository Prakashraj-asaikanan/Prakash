package Bean;

public class SucessBean {

	private String username;
	private String order_id;
	private String pdt_id;
	private int qunat;
	private int pincode;
	private String address;
	private long phnum;
	private String local;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getOrder_id() {
		return order_id;
	}
	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}
	public String getPdt_id() {
		return pdt_id;
	}
	public void setPdt_id(String pdt_id) {
		this.pdt_id = pdt_id;
	}
	public int getQunat() {
		return qunat;
	}
	public void setQunat(int qunat) {
		this.qunat = qunat;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhnum() {
		return phnum;
	}
	public void setPhnum(long phnum) {
		this.phnum = phnum;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	private String state;
	private String email;
	
}
