package Bean;
public class Index {

	private String PDT_Name;
	private String PDT_ID;
	private String PDT_PRICE;
	private String PDT_IMG;
	
	public Index()
	{
		
	}
	public Index(String PDT_Name,String PDT_ID,String PDT_PRICE,String PDT_IMG)
	{
		this.PDT_Name=PDT_Name;
		this.PDT_ID=PDT_ID;
		this.PDT_PRICE=PDT_PRICE;
		this.PDT_IMG=PDT_IMG;
	}
	
	
	public String getPDT_IMG() {
		return PDT_IMG;
	}
	public void setPDT_IMG(String imgDataBase64) {
		PDT_IMG = imgDataBase64;
	}
	public String getPDT_Name() {
		return PDT_Name;
	}
	public void setPDT_Name(String pDT_Name) {
		PDT_Name = pDT_Name;
	}
	public String getPDT_ID() {
		return PDT_ID;
	}
	public void setPDT_ID(String pDT_ID) {
		PDT_ID = pDT_ID;
	}
	public String getPDT_PRICE() {
		return PDT_PRICE;
	}
	public void setPDT_PRICE(String pDT_PRICE) {
		PDT_PRICE = pDT_PRICE;
	}
	
}
