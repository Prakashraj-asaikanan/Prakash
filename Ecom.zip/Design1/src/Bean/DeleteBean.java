package Bean;

public class DeleteBean {
	
	private String username;

	public DeleteBean()
	{
		
	}
	
	public DeleteBean(String username)
	{
		this.username=username;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	
	

}
