package Bean;

public class cate {
	
	private String ca;
	private String sub;

	public String getSub() {
		return sub;
	}
	public void setSub(String sub) {
		this.sub = sub;
	}
	public cate()
	{
		
	}
	public String getCa() {
		return ca;
	}

	public void setCa(String ca) {
		this.ca = ca;
	}
	

}
