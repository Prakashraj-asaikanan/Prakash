package Bean;

public class cartbeam {

	private String pdtimage;
	private String Price;
	private int Quantity;
	private int totalprice;
	private String ID;
	
	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public cartbeam()
	{
		
	}
	
	public cartbeam(String pdtimage,String Price,int Quantity,int totalprice,String id)
	{
		this.pdtimage=pdtimage;
		this.Price=Price;
		this.Quantity=Quantity;
		this.totalprice=totalprice;
		this.ID=id;
		}
	public String getPdtimage() {
		return pdtimage;
	}
	public void setPdtimage(String pdtimage) {
		this.pdtimage = pdtimage;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int i) {
		Quantity = i;
	}
	public int getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(int g) {
		this.totalprice = g;
	}
	
}
