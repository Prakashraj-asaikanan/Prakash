package Bean;

public class subcart {

	private String SUB_CATE;
	
	public subcart(String SUB_CATE)
	{
		this.SUB_CATE=SUB_CATE;
	}
	public String getSUB_CATE() {
		return SUB_CATE;
	}
	public void setSUB_CATE(String sUB_CATE) {
		SUB_CATE = sUB_CATE;
	}
	
	
	
}
