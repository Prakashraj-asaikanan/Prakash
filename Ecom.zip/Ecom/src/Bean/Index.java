package Bean;

public class Index {

	private String PDT_Name;
	private String PDT_ID;
	private String PDT_PRICE;
	public String getPDT_Name() {
		return PDT_Name;
	}
	public void setPDT_Name(String pDT_Name) {
		PDT_Name = pDT_Name;
	}
	public String getPDT_ID() {
		return PDT_ID;
	}
	public void setPDT_ID(String pDT_ID) {
		PDT_ID = pDT_ID;
	}
	public String getPDT_PRICE() {
		return PDT_PRICE;
	}
	public void setPDT_PRICE(String pDT_PRICE) {
		PDT_PRICE = pDT_PRICE;
	}
	
}
