package Bean;

public class Catlaog {
	 
	private String COUNTNAME;
	private String RUPEE;
	
	 public Catlaog(String COUNTNAME,String RUPEE)
	{
		this.COUNTNAME=COUNTNAME;
		this.RUPEE=RUPEE;
	}
	 public String getCOUNTNAME() {
		return COUNTNAME;
	}
	public void setCOUNTNAME(String cOUNTNAME) {
		COUNTNAME = cOUNTNAME;
	}
	public String getRUPEE() {
		return RUPEE;
	}
	public void setRUPEE(String rUPEE) {
		RUPEE = rUPEE;
	}
	

}
