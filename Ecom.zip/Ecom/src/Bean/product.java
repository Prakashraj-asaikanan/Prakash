package Bean;
import java.sql.Blob;
public class product {

	private String CATE_N;
	private String PDT_NAME;
	private String PDT_ID;
	private String 	SCAT_NAME;
	private String  PDT_DESC;
	private String  PDT_QUA;
	private String PDT_PRICE;
	private Blob PDT_IMAGE;
	private String COUNTID;
	private String ID;
	public String getCATE_N() {
		return CATE_N;
	}
	public void setCATE_N(String cATE_N) {
		CATE_N = cATE_N;
	}
	public String getPDT_NAME() {
		return PDT_NAME;
	}
	public void setPDT_NAME(String pDT_NAME) {
		PDT_NAME = pDT_NAME;
	}
	public String getPDT_ID() {
		return PDT_ID;
	}
	public void setPDT_ID(String pDT_ID) {
		PDT_ID = pDT_ID;
	}
	public String getSCAT_NAME() {
		return SCAT_NAME;
	}
	public void setSCAT_NAME(String sCAT_NAME) {
		SCAT_NAME = sCAT_NAME;
	}
	public String getPDT_DESC() {
		return PDT_DESC;
	}
	public void setPDT_DESC(String pDT_DESC) {
		PDT_DESC = pDT_DESC;
	}
	public String getPDT_QUA() {
		return PDT_QUA;
	}
	public void setPDT_QUA(String pDT_QUA) {
		PDT_QUA = pDT_QUA;
	}
	public String getPDT_PRICE() {
		return PDT_PRICE;
	}
	public void setPDT_PRICE(String pDT_PRICE) {
		PDT_PRICE = pDT_PRICE;
	}
	
	
	public Blob getPDT_IMAGE() {
		return PDT_IMAGE;
	}
	public void setPDT_IMAGE(Blob pDT_IMAGE) {
		PDT_IMAGE = pDT_IMAGE;
	}
	public String getCOUNTID() {
		return COUNTID;
	}
	public void setCOUNTID(String cOUNTID) {
		COUNTID = cOUNTID;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	
	
}
