package Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/DeleteCart")
public class DeleteCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public DeleteCart() {
        super();   }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
    	try{
    	 int id  = Integer.parseInt( request.getParameter("PDT_id"));
    	    Connection con=DBConnection.getConnection();
    	    PreparedStatement ps = con.prepareStatement("delete from CART where PDT_ID = ? ");
    	    ps.setInt(1, id);
    	    int i = ps.executeUpdate();
    	    if(i==0)
    	    {
    	        //System.out.println("yes");
    	    response.sendRedirect(request.getHeader("referer"));
    	    
    	    }
    	    else
    	    {
    	        //System.out.println("No");
    	        response.sendRedirect(request.getHeader("referer"));    
    	        
    	    }
    	}
    catch(Exception e)
    	{
    		e.printStackTrace();
    		}
    	}

}
