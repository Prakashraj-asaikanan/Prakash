package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Servlet.DBConnection;

@WebServlet("/Pay")
public class Pay extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Pay() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        
        HttpSession session=request.getSession();
        PrintWriter out=response.getWriter();
        try
        {
        Connection con=DBConnection.getConnection();
        PreparedStatement psw=null;
        String username=(String) session.getAttribute("username");
        String pdtname=request.getParameter("pname");
        String id=String.valueOf(request.getParameter("pid"));
       // System.out.print(id);
        String er=request.getParameter("qty");
        System.out.println(er);
        int qt=Integer.parseInt(er);
        psw=con.prepareStatement("insert into cart values(?,?,?,?)");
		psw.setString(1,username);
		psw.setString(2,id);
		psw.setString(3,pdtname);
		psw.setInt(4,qt);
		int rsd=psw.executeUpdate();
		session.setAttribute("qty",er);
        if(rsd>0)
        {
        	response.sendRedirect("cart.jsp?id="+id);
     
        }
        else
        {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Problem in Adding Cart');");
            out.println("location='Home.jsp';");
            out.println("</script>");
        }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        }
    }


