package Servlet;

import java.beans.Statement;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class product
 */
@WebServlet("/product")
public class prdt extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String id=request.getParameter("id");
try
{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();
		Connection c=DBConnection.getConnection();
		String Query="SELECT * FROM PRODUCT where PDT_ID="+id+"";
		Statement st=(Statement) c.createStatement();

		ResultSet rs=((java.sql.Statement) st).executeQuery(Query);
		Blob blo=null;
		String qun="";
		String imgDataBase64="";
		while(rs.next()){
			qun=rs.getString(6);
			blo=rs.getBlob(8);
			int size=(int)blo.length();
			byte[] bloa=blo.getBytes(1,size);
			imgDataBase64=new String(Base64.getEncoder().encode(bloa));
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}

}
}
