package Servlet;
import Dao.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.loginb;
@WebServlet(name="Sign",urlPatterns={"/Sign"})
public class Sign extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//private static final String SignDao = null;
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
Connection c = null;		
		try
		{
response.setContentType("text/html");  
PrintWriter out=response.getWriter();  
String s=request.getParameter("username");
String s1=request.getParameter("Email");
String s2=request.getParameter("Password");
loginb e=new loginb();
e.setUsername(s);
e.setEmail(s1);
e.setPassword(s2);
String status=null;
int j=SignDao.save(e);
if(j>0)
{
	out.print("<script>");
out.print("alert('Sucessfully registered')");
out.print("</script>");
response.sendRedirect("index.jsp");  
}
else
{  
	out.print("<script>");
	out.print("alert('Please Try Again')");
	out.print("</script>");
	response.sendRedirect("login.jsp");  
} }
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
