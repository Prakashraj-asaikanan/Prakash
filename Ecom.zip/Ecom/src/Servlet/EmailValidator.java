package Servlet;

public class EmailValidator {

	public EmailValidator() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
