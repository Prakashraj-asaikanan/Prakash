package Servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Bean.loginpa;
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 
		Connection c;
		try {
			c = DBConnection.getConnection();
		} catch (NullPointerException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try
		{
			response.setContentType("text/html");  
	 c = DBConnection.getConnection();
	
		PreparedStatement ps=null;
		HttpSession ses=request.getSession();
		String username=request.getParameter("username");
		String pass=request.getParameter("Password");
		PrintWriter out=response.getWriter();
		System.out.print(pass);
		if((username.equals("PrakasH")) && (pass.equals("passWord")))
		{
			response.sendRedirect("admin.jsp");
		}
		else
		{
		loginpa lp=new loginpa();
		lp.setUsername(username);
		lp.setPassword(pass);
		ResultSet rs=null;
		String sr="";
		String state="select PASSWORD from reg12 where USERNAME=?";
		 ps=c.prepareStatement(state);
		ps.setString(1,lp.getUsername());
		rs=ps.executeQuery();
		while(rs.next())
		{
			sr=rs.getString(1);
		}
		
		if(sr.equals(pass))
		{
			ses.setMaxInactiveInterval(1000);
			HttpSession session=request.getSession(); 
	        session.setAttribute("username",username);
			String from=request.getParameter("from");
//			System.out.print(from);
//			if(from!=null)
//			{
//				response.sendRedirect(from);
//			}
//			else
//			{
//				
			response.sendRedirect("index.jsp");		 
 
			//	}
		}
		else
		{
		
			out.println("<script>");
			out.println("alert('Wrong Password/username');");			
			out.println("location='login.jsp';");
			out.println("</script>");
		}
		}
		}
			catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
}

 