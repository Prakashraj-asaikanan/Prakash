package Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Servlet.DBConnection;
@WebServlet("/Order")
public class Order extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Order() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con=null;
		HttpSession se=request.getSession();
		String uname=(String) se.getAttribute("username");
		try {
			 con=DBConnection.getConnection();
		
		
		PreparedStatement ps=con.prepareStatement("select * from userorder where username=?");
		ps.setString(1, uname);
		ResultSet rs=ps.executeQuery();
		String pdt_id="";
		int quan=0;
				String quan1="";
		while(rs.next())	
		{
			pdt_id=rs.getString(3);
			quan=rs.getInt(4);
		
				PreparedStatement ps1=con.prepareStatement("select * from product where pdt_id=? ");
				ps1.setString(1,pdt_id);
				ResultSet rs1=ps1.executeQuery();
				while(rs1.next())
				{
					quan1=rs1.getString(6);
				}
		} 
		int y=Integer.parseInt(quan1);
		int quan2=y-quan;
		PreparedStatement ps2=con.prepareStatement("update product set pdt_qua=? where pdt_id=?");
		//char[] quan2 = null;
		ps2.setString(1,String.valueOf(quan2));
		ps2.setString(2,pdt_id);
	int ep=	ps2.executeUpdate();
		if(ep>0)
		{
			response.sendRedirect("index.jsp");
		}
		}
		catch (NullPointerException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}