package Servlet;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
//import javax.servlet.http.Part;

/**
 * Servlet implementation class adminDao
 */
@WebServlet("/adminDao")
@MultipartConfig
public class adminDao extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	//@SuppressWarnings({ "resource", "null" })
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection	c ;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		c= DriverManager.getConnection("jdbc:oracle:thin:@116.51.0.187:1521:oracle","PRAKASH","prakash");
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try
		{			
	 c = DBConnection.getConnection();
			PreparedStatement ps;
			PreparedStatement ps1;
			PreparedStatement ps2;
			PreparedStatement ps3 = null;
		String cname=request.getParameter("COUNTNAME");
		String rupe	=request.getParameter("RUPEE");
		ps=c.prepareStatement("insert into catalog values(countr_id.nextval,?,?)");
		ps.setString(1,cname);
		ps.setString(2,rupe);		
	ps.executeUpdate();
		
		//category query
		String cate=request.getParameter("CATE_N");
		String subcate=request.getParameter("SUB_CATE");
		PreparedStatement psd=c.prepareStatement("select countid from catalog where catalog.countname='"+cname+"'");
		int stry = 0;
		ResultSet rs9=psd.executeQuery();
		while(rs9.next())
		{
			stry=rs9.getInt("countid");
		}
		
		
		
		
		try{
		ps1=c.prepareStatement("insert into category values(?,?,?,?)");
		ps1.setString(1,cate);
		ps1.setString(2,subcate);
		ps1.setInt(3,stry);
		ps1.setInt(4, 3);
		ps1.executeUpdate();
		//subcategory query
	//	String subcate=request.getParameter("SUB_CATE");
		ps2=c.prepareStatement("insert into subcat values(?,sub_id.nextval)");
		ps2.setString(1,subcate);
		ps2.executeUpdate();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		PrintWriter out=response.getWriter();
		Part photo=null;
		InputStream in = null;
		try
		{
			photo=request.getPart("pdt_image");
			
			in=photo.getInputStream();
		}
		catch(Exception e){
			System.out.print(e.getMessage());
		}
		String pdtname=request.getParameter("pdt_name");
		String pdtdesc=request.getParameter("pdt_desc");
		String pdtqua=request.getParameter("pdt_qua");
		String pdtprice=request.getParameter("pdt_price");
		//String pdtimage=request.getParameter("pdt_image");
		
		//FileInputStream fin = new FileInputStream("f:\\images/product2.jpg");
try{	
	//PreparedStatement fg=c.prepareStatement("select count_id from catalog where catalog.countname='"+cname+"'");
ps3=c.prepareStatement("insert into product values(?,?,pd_id.nextval,?,?,?,?,?,?,?)");
	ps3.setString(1,cate);
		ps3.setString(2,pdtname);
		ps3.setString(3,subcate);
		ps3.setString(4,pdtdesc);
		ps3.setString(5, pdtqua);
		ps3.setString(6,pdtprice);
		ps3.setBlob(7,in);
		ps3.setInt(8,stry);	
		ps3.setInt(9,stry);
		ps3.executeUpdate();
}
catch(Exception e)
{
	e.printStackTrace();
}
				out.println("<script type=\"text/javascript\">");
					   out.println("alert('Successfully Registered');");
					   out.println("location='admin.jsp';");
					   out.println("</script>");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
