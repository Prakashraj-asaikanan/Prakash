package Servlet;
import java.util.Random;
import java.io.IOException;
import java.sql.Connection;


import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/paydao")
public class paydao extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public paydao() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try
		{
			System.out.print(44);
			 HttpSession session=request.getSession(); 
			 int qty=Integer.parseInt((String) session.getAttribute("qty"));
			String it=request.getParameter("id");
				int pino=Integer.parseInt(request.getParameter("pin"));
			String add=(String)request.getParameter("add");
			long phno=Long.parseLong(request.getParameter("phno"));
			//int qty=(Integer.parseInt( (String) session.getAttribute("qty")));
			String local=request.getParameter("local");
			String state=request.getParameter("state");
		//	System.out.print(qty);
			Connection con=DBConnection.getConnection();
			String username = (String)session.getAttribute("username");
			System.out.print(username);
			Random rand = new Random(); 
			 String pickedNumber = (String.valueOf(rand.nextInt(2000) + 1)); 
			 System.out.print(pickedNumber);
			 PreparedStatement pw=con.prepareStatement("INSERT INTO USERORDER values(?,?,?,?,?,?,?,?,?)");
				pw.setString(1, username);
				pw.setString(2, pickedNumber);
				pw.setString(3,it);
				pw.setInt(4,qty);
				pw.setInt(5,pino);
				pw.setString(6,add);
				pw.setLong(7,phno);
				pw.setString(8,local);
				pw.setString(9,state);
			int count=0;
				int i=pw.executeUpdate();
				if(i>0)
				{
					PreparedStatement pw4=con.prepareStatement("delete from CART where PDT_ID = ? and username= ?");
					pw4.setString(1,it);
					pw4.setString(2,username);
					System.out.print(64);
				int cn=	pw4.executeUpdate();
				
				
					 if(cn>0)
					 {
						System.out.print(85);
						response.sendRedirect("Sucess.jsp");}
					 else
					 {
						 response.sendRedirect("Failure.jsp");
					 }
				}
				else
				{
					response.sendRedirect("index.jsp");
				}
					
				
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
