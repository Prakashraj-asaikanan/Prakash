package Servlet;
import java.sql.*;
public class DBConnection {

	public static Connection getConnection() throws SQLException,NullPointerException
	{
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection c = null;
		try {
			c= DriverManager.getConnection("jdbc:oracle:thin:@106.51.0.187:1521:oracle","PRAKASH","prakash");
		}
		catch(Exception e)
		
		{e.printStackTrace();
		}

		
		return c;
	}
	
}


